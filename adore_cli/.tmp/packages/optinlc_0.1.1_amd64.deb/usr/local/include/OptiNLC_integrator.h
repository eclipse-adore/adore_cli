/*
 * OptiNLC_Integrator.h
 *
 * This file defines the OptiNLC_Integrator class, responsible for numerically integrating dynamic models within the OptiNLC toolbox. It utilizes the Runge-Kutta 4th order (RK4) method.
 *
 * Author: Reza Dariani
 * Email: reza.dariani@dlr.de
 */
#ifndef OPTINLC_INTEGRATOR_H
#define OPTINLC_INTEGRATOR_H

#include <iostream>
#include <functional>
#include "OptiNLC_Data.h"

// Forward declare the OCP class
template <typename Scalar, int InputSize, int StateSize, int ConstraintSize, int NumberOfControlPoints>
class OptiNLC_OCP;

template <typename Scalar, int InputSize, int StateSize, int ConstraintSize, int NumberOfControlPoints>
class OptiNLC_Integrator {
public:
    using StateVector = typename OptiNLC_OCP<Scalar, InputSize, StateSize, ConstraintSize, NumberOfControlPoints>::StateVector;
    using InputVector = typename OptiNLC_OCP<Scalar, InputSize, StateSize, ConstraintSize, NumberOfControlPoints>::InputVector;
    using DynamicModelFunction = typename OptiNLC_OCP<Scalar, InputSize, StateSize, ConstraintSize, NumberOfControlPoints>::DynamicModelFunction;

    OptiNLC_Integrator(Scalar step_size)
        : step_size_(step_size) {}

    void setDynamicModel(const DynamicModelFunction& dynamic_model)
    {
        dynamic_model_ = dynamic_model;
    }

    void setTimeStep(double timeStep){
        step_size_ = timeStep;
    }

    VECTOR<double, StateSize> integrateRK4(const VECTOR<double, StateSize>& state, const VECTOR<double, InputSize>&  input, double currentTime, void* userData = nullptr) {
        double h_step_site_ = step_size_ / 2.0;
        VECTOR<double, StateSize> k1, k2, k3, k4, state_new, temp_state;

        // Compute k1
        dynamic_model_(state, input, k1,currentTime , userData);

        // Compute k2
        for (int i = 0; i < StateSize; i++) temp_state[i] = state[i] + (h_step_site_) * k1[i];
        dynamic_model_(temp_state, input, k2,currentTime, userData);

        // Compute k3
        for (int i = 0; i < StateSize; i++) temp_state[i] = state[i] + (h_step_site_) * k2[i];
        dynamic_model_(temp_state, input, k3, currentTime, userData);

        // Compute k4
        for (int i = 0; i < StateSize; i++) temp_state[i] = state[i] + step_size_ * k3[i];
        dynamic_model_(temp_state, input, k4, currentTime, userData);

        // Update the state using the RK4 formula
        for (int i = 0; i < StateSize; i++) {
            state_new[i] = (state[i] + (step_size_ / 6.0) * (k1[i] + 2.0 * k2[i] + 2.0 * k3[i] + k4[i]));
        }
        return state_new;
    }

private:
    DynamicModelFunction dynamic_model_;
    Scalar step_size_;
};

#endif // OPTINLC_INTEGRATOR_H
