/*
 * OptiNLC_Options.h
 *
 * This file defines the data structure for the options of the OptiNLC toolbox.
 * OptiNLC is designed to solve nonlinear optimal control problems based on the line search Sequential Quadratic Programming (SQP) method.
 *
 * Author: Reza Dariani
 * Email: reza.dariani@dlr.de
 */

#ifndef OPTINLC_OPTIONS_H
#define OPTINLC_OPTIONS_H

// Define your data structure for OptiNLC_Options
typedef struct {
    double  timeStep;                       // Time step for the optimization
    int     intermediateIntegration;        // Intermediate integration steps
    double  perturbation;                   // Perturbation value for numerical differentiation
    double  convergenceThreshold;           // Convergence threshold for optimization
    double  OptiNLC_ACC;                    // Accuracy for the Sequential Quadratic Programming (SQP) method
    double  OptiNLC_time_limit;             // Time limit for OptiNLC solver
    int     maxNumberOfIteration;           // Maximum number of iterations for optimization
    bool    OSQP_verbose;                   // Verbosity option for OSQP solver
    bool    OSQP_warm_starting;             // Warm-starting option for OSQP solver
    int     OSQP_max_iter;                 // Maximum number of iterations for OSQP solver
    double  OSQP_time_limit;                // Time limit for OSQP solver
    double  OSQP_eps_abs;                   // Absolute tolerance for OSQP solver
    double  OSQP_eps_rel;                   // Relative tolerance for OSQP solver
} OptiNLC_Options;

// Function to set default values for OptiNLC_Options
inline void setDefaultOptiNLCOptions(OptiNLC_Options *options) {
    options->timeStep                   = 0.1;
    options->intermediateIntegration    = 10;
    options->perturbation               = 1.e-12;
    options->convergenceThreshold       = 1.e-10;
    options->OptiNLC_ACC                = 1e-6;
    options->OptiNLC_time_limit         = 0.5;
    options->maxNumberOfIteration       = 100;
    options->OSQP_verbose               = false;
    options->OSQP_warm_starting         = true;
    options->OSQP_max_iter              = 100;
    options->OSQP_time_limit            = 0.01;
    options->OSQP_eps_abs               = 1e-5;
    options->OSQP_eps_rel               = 1e-5;
}
#endif // OPTINLC_OPTIONS_H
