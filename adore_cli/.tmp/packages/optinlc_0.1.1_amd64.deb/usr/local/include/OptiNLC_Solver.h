/*
 * OptiNLC_Solver.h
 *
 * This file is the solver for nonlinear optimal control problem for the OptiNLC toolbox.
 * OptiNLC is specialized for solving nonlinear optimal control problems using the line search Sequential Quadratic Programming (SQP) method.
 *
 * Author: Reza Dariani
 * Email: reza.dariani@dlr.de
 */
#ifndef OPTINLC_SOLVER_H
#define OPTINLC_SOLVER_H

#include "OptiNLC_OCP.h"  // Include the OCP class header
#include "OptiNLC_Solver.h"
#include "OptiNLC_SQP.h"
//#include "SQP.h"
//#include "Tools.h"







using namespace std;

template <typename Scalar, int InputSize, int StateSize, int ConstraintSize, int NumberOfControlPoints>
class OptiNLC_Solver {
public:
    // Define any necessary types or member functions for the solver here
    // Type aliases for the OCP types
    
    using OCPType = OptiNLC_OCP<Scalar, InputSize, StateSize , ConstraintSize,NumberOfControlPoints>;
    using StateVector = typename OCPType::StateVector;
    using IntegratedStateVector = typename OCPType::IntegratedStateVector;
    using InputVector = typename OCPType::InputVector;
    using InputVectorHorizon = typename OCPType::InputVectorHorizon;
    using ConstraintVector = typename OCPType::ConstraintVector;
    using ConstraintHorizon = typename OCPType::ConstraintHorizon;
    using TimeVector = typename OCPType::TimeVector;
    using BoundaryVector = VECTOR<Scalar, InputSize*NumberOfControlPoints + StateSize*(NumberOfControlPoints+1) + ConstraintSize*NumberOfControlPoints>;
    OptiNLC_Options *options;
    // Constructor
    OptiNLC_Solver(const OCPType&  ocp): ocp_(ocp) {
       options = ocp.options;
    }
    TimeVector getTime(){
        return ocp_.getTime();
    }
    double getFinalObjectiveFunction(){
        return final_obj_function;
    }




    // Method to solve the OCP using an SQP solver
    void solve(double currentTime, const StateVector& state, const InputVector& input ) {
        
        ocp_.createTimeVector(currentTime); 
        initializeAndSimulate(state,input);      
        evaluateBoundaries();

        auto objectiveFunctionLambda = [&](const StateVector& x, const InputVector& u, double currentTime) {
            return objectiveFunction(x,u,currentTime);
        };
        auto constraintsFunctionLambda = [&](const IntegratedStateVector& x,const InputVectorHorizon& u) {
           return constraintsFunction(x,u);
        };    
        auto IntegratorFunctionLambda = [&](const StateVector& x, const InputVectorHorizon& u, const TimeVector& time) {
           return integrateFunction(x,u,time);
        };             

        
      
        constexpr int numberOfContraints = InputSize*NumberOfControlPoints + ConstraintSize*NumberOfControlPoints + StateSize*(NumberOfControlPoints+1);
        OptiNLC_Engine<double, InputSize*NumberOfControlPoints, StateSize ,numberOfContraints, NumberOfControlPoints> 
        problem(inputVectorHorizon,getL(),getU(), objectiveFunctionLambda,constraintsFunctionLambda,IntegratorFunctionLambda);
        OptiNLC_SQP<double, InputSize*NumberOfControlPoints,StateSize, numberOfContraints, NumberOfControlPoints> SQP(problem,options);//, inputVectorHorizon);
        
        SQP.RUN(state, ocp_.getTime());
        optimal_inputs  = SQP.get_u();
        optimal_states = ocp_.integrate(state,optimal_inputs,ocp_.getTime());
        final_obj_function = SQP.obj_f;
        //optimal_states.print(NumberOfControlPoints+1,StateSize);
    }
    InputVectorHorizon get_optimal_inputs() {return optimal_inputs;}
     IntegratedStateVector get_optimal_states() {return optimal_states;}
private:
    double final_obj_function;
    int N; // Number of optimization parameter
    InputVectorHorizon inputVectorHorizon, input_lb, input_ub, optimal_inputs;
    IntegratedStateVector integratedStates, state_lb, state_ub, optimal_states;
    VECTOR<Scalar, ConstraintSize * NumberOfControlPoints> constraint_lb, constraint_ub;
        //std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
        //double QP_time_total;  
        //Tools *tools;  
        const OptiNLC_OCP<Scalar, InputSize, StateSize,  ConstraintSize,NumberOfControlPoints>& ocp_;  // Reference to the OCP instance

   


    void evaluateBoundaries()
    {
        input_lb.clear();
        input_ub.clear();
        state_lb.clear();
        state_ub.clear();
        constraint_lb.clear();
        constraint_ub.clear();        
        VECTOR<Scalar, StateSize> tmp_state;
        VECTOR<Scalar, InputSize> tmp_input;
        // at t0
        tmp_state.set(&integratedStates[0]);
        tmp_input.set(&inputVectorHorizon[0]);
        input_lb.setSubVector(ocp_.getInputLowerBounds(tmp_state, tmp_input), 0);
        input_ub.setSubVector(ocp_.getInputUpperBounds(tmp_state, tmp_input), 0);
        state_lb.setSubVector(tmp_state,0);
        state_ub.setSubVector(tmp_state,0);
        if(ConstraintSize){
            constraint_lb.setSubVector(ocp_.getFunctionConstraintsLowerBounds(tmp_state, tmp_input),0);
            constraint_ub.setSubVector(ocp_.getFunctionConstraintsUpperBounds(tmp_state, tmp_input),0); 
        } 
        for (int i = 1; i < NumberOfControlPoints; ++i) { 
            tmp_state.set(&integratedStates[i*StateSize]);
            tmp_input.set(&inputVectorHorizon[i*InputSize]);
            input_lb.setSubVector(ocp_.getInputLowerBounds(tmp_state, tmp_input), i*InputSize);
            input_ub.setSubVector(ocp_.getInputUpperBounds(tmp_state, tmp_input), i*InputSize);
            state_lb.setSubVector(ocp_.getStateLowerBounds(tmp_state, tmp_input), i*StateSize);
            state_ub.setSubVector(ocp_.getStateUpperBounds(tmp_state, tmp_input), i*StateSize);
            if(ConstraintSize){
                constraint_lb.setSubVector(ocp_.getFunctionConstraintsLowerBounds(tmp_state, tmp_input),i*ConstraintSize);
                constraint_ub.setSubVector(ocp_.getFunctionConstraintsUpperBounds(tmp_state, tmp_input),i*ConstraintSize);
                }
        }
        tmp_state.set(&integratedStates[NumberOfControlPoints*StateSize]);
        state_lb.setSubVector(ocp_.getStateLowerBounds(tmp_state, tmp_input), NumberOfControlPoints*StateSize);
        state_ub.setSubVector(ocp_.getStateUpperBounds(tmp_state, tmp_input), NumberOfControlPoints*StateSize);
    }

    BoundaryVector getL()
    {
        BoundaryVector L;
        L.setSubVector(input_lb,0);
        L.setSubVector(state_lb,input_lb.size());
        L.setSubVector(constraint_lb,input_lb.size()+state_lb.size());
        return L;
    }
    BoundaryVector getU()
    {
        BoundaryVector U;
        U.setSubVector(input_ub,0);
        U.setSubVector(state_ub,input_ub.size());
        U.setSubVector(constraint_ub,input_ub.size()+state_ub.size());
        return U;      
    }    
    // Define a member function to create the constraints function lambda
    BoundaryVector  constraintsFunction(const IntegratedStateVector& integratedStates, const InputVectorHorizon& inputHorizon) {


            BoundaryVector result;
            ConstraintHorizon constraintHorizon;
            if(ConstraintSize) constraintHorizon = ocp_.evaluateConstraintsHorizon(integratedStates,inputHorizon);           
            
            if(ConstraintSize) { 
                std::memcpy(&result[0], &inputHorizon[0], sizeof(inputHorizon));
                std::memcpy(&result[inputHorizon.size()], &integratedStates[0], sizeof(integratedStates));
                std::memcpy(&result[inputHorizon.size()+ integratedStates.size()], &constraintHorizon[0], sizeof(constraintHorizon));
            } else {
                std::memcpy(&result[0], &inputHorizon[0], sizeof(inputHorizon));
                std::memcpy(&result[inputHorizon.size()], &integratedStates[0], sizeof(integratedStates));
            }

            return result;

   }

    
    void initializeAndSimulate(const StateVector& state, const InputVector& input) {
        auto time = getTime();
        IntegratedStateVector result;
        StateVector tmp_state;
        integratedStates.setSubVector(state,0);
        inputVectorHorizon.setSubVector(input,0);
        tmp_state.set(state);
        int IN = ocp_.getIntermediateIntegration();
        double dt_in = options->timeStep / IN;
        ocp_.setIntegratorTimeStep(ocp_.getTimeStep()/IN);
        // Initialize inputs for the entire horizon
        for (int i = 1; i < NumberOfControlPoints; ++i) { 
            for(int j=0; j<IN; j++){
                tmp_state = ocp_.integrateDynamicModel(tmp_state, input, time[i-1]+ j*dt_in);
            }
            
            inputVectorHorizon.setSubVector(ocp_.computeInputUpdate(tmp_state,input, time[i]), i*InputSize);
            integratedStates.setSubVector(tmp_state, i*StateSize);            
        }  
        /* 
        for(int j=0; j<IN; j++){
            tmp_state = ocp_.integrateDynamicModel(tmp_state, input, time[NumberOfControlPoints]+j*dt_in);
        }  
        integratedStates.setSubVector(tmp_state, NumberOfControlPoints*StateSize);
    */
        
    }
    // Define a member function to create the objective function lambda
    double objectiveFunction(const StateVector& x, const InputVector& u, double currentTime) {
       
        return ocp_.computeObjective(x,u,currentTime);
    
    }
   IntegratedStateVector integrateFunction(const StateVector& x, const InputVectorHorizon& u,const TimeVector& time){
        return ocp_.integrate(x,u, time);
    }
   

  
 




  


//FOR CONSTRAINTS EVALUATION NOT ALWAYS INTEGRATION IS NEEDED

};

#endif  // OPTINLC_SOLVER_H
