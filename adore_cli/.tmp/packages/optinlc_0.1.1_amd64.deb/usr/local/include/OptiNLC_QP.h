/*
 * OptiNLC_QP.h
 *
 * This file solves the QP problem for the OptiNLC toolbox.
 * OptiNLC is specialized for solving nonlinear optimal control problems using the line search Sequential Quadratic Programming (SQP) method.
 *
 * Author: Reza Dariani
 * Email: reza.dariani@dlr.de
 */

#ifndef OPTINLC_QP
#define OPTINLC_QP
#include <float.h>
#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/Core>
#include <eigen3/Eigen/Sparse>
#include <cstddef>
#include <vector>
#include "osqp.h"

        # ifndef DFLOAT         // Doubles
        typedef double c_float; /* for numerical values  */
        # else                  // Floats
        typedef float c_float;  /* for numerical values  */
        # endif /* ifndef DFLOAT */

template <typename Scalar, int InputSize, int StateSize, int ConstraintSize, int NumberOfControlPoints>
class OptiNLC_QP {
public:
    OptiNLC_QP(OptiNLC_Options *options) {
        // Constructor code goes here (if any)
        debug_qp_time = 0.0;
        this->options = options;
    }
    struct SOLUTION
    {
        VECTOR<Scalar, InputSize> primal;
        VECTOR<Scalar,ConstraintSize> dual;
        VECTOR<Scalar,ConstraintSize>  constJ_p; //product of constraint Jacobian with p (direction) i.e. primal
        double run_time;
        int status;
    };


    SOLUTION solveQP(const MATRIX<ConstraintSize,InputSize>& A, 
                    const Eigen::MatrixXd& P, 
                    const VECTOR<Scalar, InputSize> & q, 
                    const VECTOR <Scalar, ConstraintSize>& constr, 
                    const VECTOR <Scalar, ConstraintSize>& l, 
                    const VECTOR <Scalar, ConstraintSize>& u) const {

                auto start_0 = std::chrono::high_resolution_clock::now();
                OSQPInt exitflag = 0;
                SOLUTION solution;           
                solution.status = 11; //status initialized to unsolved
                const VECTOR <Scalar, ConstraintSize> lb, ub;
                lb = l - constr;
                ub = u - constr;
                double tmp_q[InputSize];
                std::memcpy(&tmp_q[0], &q[0], InputSize * sizeof(double));
                double tmp_l[ConstraintSize];
                std::memcpy(&tmp_l[0], &lb[0], ConstraintSize * sizeof(double));
                double tmp_u[ConstraintSize];
                std::memcpy(&tmp_u[0], &ub[0], ConstraintSize * sizeof(double));;
                OSQPWorkspace* work;
                OSQPSolver   *solver;
                OSQPSettings* settings = (OSQPSettings*) malloc(sizeof(OSQPSettings));
                CompactArrays P_ca = get_ca(P);
                A.getSparsity();
                auto A_dense = A.sparse;
                OSQPCscMatrix* _P = malloc(sizeof(OSQPCscMatrix));
                OSQPCscMatrix* _A = malloc(sizeof(OSQPCscMatrix));
                csc_set_data(_P, InputSize, InputSize, P_ca.nnz, P_ca.x.data(),  P_ca.i.data(), P_ca.o.data());
                csc_set_data(_A, ConstraintSize, InputSize, A_dense.getNonZeros() , A_dense.valuePtr(), A_dense.innerIndexPtr(), A_dense.outerIndexPtr());                
                osqp_set_default_settings(settings);
                settings->verbose = options->OSQP_verbose;
                settings->max_iter = options->OSQP_max_iter;
                //settings->max_iter = 20000;
                settings-> warm_starting = options->OSQP_warm_starting;
                settings->time_limit = options->OSQP_time_limit;
                //settings->eps_abs = 1e-7;
                settings->eps_abs = options->OSQP_eps_abs;
                settings->eps_rel = options->OSQP_eps_rel;
                //std::cout<<"\ntime milliseconds prep: "<<std::chrono::duration<double, std::milli>(std::chrono::high_resolution_clock::now() - start_0).count()<<"\n"; 
                auto start_1 = std::chrono::high_resolution_clock::now();
                exitflag = osqp_setup(&solver, _P, &tmp_q[0], _A, &tmp_l[0], &tmp_u[0], ConstraintSize, InputSize, settings);
               
                
                //debug_qp_time = std::chrono::duration<double, std::milli>(std::chrono::high_resolution_clock::now() - start).count();
                // Solve problem 
                if (!exitflag) exitflag = osqp_solve(solver);
                // std::cout<<"\ntime milliseconds osqp: "<<std::chrono::duration<double, std::milli>(std::chrono::high_resolution_clock::now() - start_1).count()<<"\n"; 
                // std::cout<<"\ntime milliseconds osqp: "<<solver->info->run_time;
                auto start_2 = std::chrono::high_resolution_clock::now();
                /*
                if (solver->info->status_val == 1)          std::cout<<"\nQP STATUS: solved";
                if (solver->info->status_val == 2)          std::cout<<"\nQP STATUS: solved inaccurate";
                if (solver->info->status_val == 3)          std::cout<<"\nQP STATUS: primal infeasible";
                if (solver->info->status_val == 4)          std::cout<<"\nQP STATUS: primal infeasible inaccurate ";
                if (solver->info->status_val == 5)          std::cout<<"\nQP STATUS: dual infeasible   ";
                if (solver->info->status_val == 6)          std::cout<<"\nQP STATUS: dual infeasible inaccurate    ";
                if (solver->info->status_val == 7)          std::cout<<"\nQP STATUS: maximum iterations reached    ";
                if (solver->info->status_val == 8)          std::cout<<"\nQP STATUS: run time limit reached    ";
                if (solver->info->status_val == 9)          std::cout<<"\nQP STATUS: problem non convex   ";
                if (solver->info->status_val == 10)         std::cout<<"\nQP STATUS: interrupted by user    ";
                if (solver->info->status_val == 11)         std::cout<<"\nQP STATUS: unsolved   ";
                */
                if(solver->info->status_val == 9)
                {

                    std::cout<<"\nsolver->info->status_val == 9\n";
                    Eigen::MatrixXd P_copy = P;  // Make a non-const copy
                    P_copy.resize(InputSize, InputSize);
                    P_copy.setIdentity();

                    P_ca = get_ca(P_copy);
                    csc_set_data(_P, InputSize, InputSize, P_ca.nnz, P_ca.x.data(),  P_ca.i.data(), P_ca.o.data());
                    exitflag = osqp_setup(&solver, _P, &tmp_q[0], _A, &tmp_l[0], &tmp_u[0], ConstraintSize, InputSize, settings);
                    if (solver->info->status_val == 9)          std::cout<<"\nQP STATUS: problem non convex   ";
                    if (solver->info->status_val == 1)          std::cout<<"\nQP STATUS: solved";
                    if (solver->info->status_val == 2)          std::cout<<"\nQP STATUS: solved inaccurate";  
                    std::cout<<"\n******************\n"<<   solver->info->status_val;               
               }
             // std::cout<<"\n******************\n"<<   solver->info->iter; 
                for(int i=0; i<InputSize; i++) { solution.primal[i] = solver->solution->x[i];   }
                for(int i=0; i<ConstraintSize; i++) { solution.dual[i] = solver->solution->y[i]; }
                solution.constJ_p =  (A * solution.primal);
                solution.run_time =  solver->info->run_time;
                osqp_cleanup(solver);
                if (_A) free(_A);
                if (_P) free(_P);
                if (settings) free(settings);
                //std::cout<<"\nprimal\n";solution.primal.print();
                //std::cout<<"\ndual\n";solution.dual.print();
                //std::cout<<"\nConstJp\n";solution.constJ_p .print();
                //std::cout<<"\ntime milliseconds: "<<std::chrono::duration<double, std::milli>(std::chrono::high_resolution_clock::now() - start).count()<<"\n";
                //std::cout<<"\ntime milliseconds post: "<<std::chrono::duration<double, std::milli>(std::chrono::high_resolution_clock::now() - start_2).count()<<"\n"; 
                return solution;
    }

  
    

 
            //double *l_cf;
            //double *u_cf;
           // double *q_cf;
    struct CompactArrays
    {
        std::vector<c_float> x; //values
        std::vector<long long int> i; //inner indices
        std::vector<long long int> o; //outer indices
        int nnz;            //number of non-zeros elements
        int nc;
        int nr;

    } ;//P_ca, A_ca;
    static CompactArrays get_ca (Eigen::MatrixXd P )
    {
    
        CompactArrays ca;
        ca.nr = P.rows();
        ca.nc = P.cols();
        Eigen::SparseMatrix<double>  P_spr = P.sparseView(0.00); 
        int NumNonZeros =  P_spr.nonZeros();
        int innerSize =  P_spr.innerSize();
        int outerSize =  P_spr.outerSize();
        ca.nnz = NumNonZeros;
        double P_x[NumNonZeros];
        double P_i[NumNonZeros];
        for(int i=0; i<NumNonZeros; i++)
        {
            ca.x.push_back(P_spr.valuePtr()[i]);
            ca.i.push_back(P_spr.innerIndexPtr()[i]);
        }
        for (int i=0; i<outerSize; i++)
        {
            ca.o.push_back(P_spr.outerIndexPtr()[i]);             
        }
        ca.o.push_back(P_spr.outerIndexPtr()[outerSize]);
        return ca;
    }
    double getTotalTime() {return debug_qp_time;}
      private:
      OptiNLC_Options *options;
        double debug_qp_time ;
        Eigen::MatrixXd makeUpperTriangular(const Eigen::MatrixXd& inputMatrix) {
            Eigen::MatrixXd upperTriangular = inputMatrix;  // Create a copy of the input matrix

            int numRows = upperTriangular.rows();
            int numCols = upperTriangular.cols();

            for (int col = 0; col < numCols - 1; ++col) {
                for (int row = col + 1; row < numRows; ++row) {
                    double factor = upperTriangular(row, col) / upperTriangular(col, col);
                    upperTriangular.row(row) -= factor * upperTriangular.row(col);
                }
            }

            return upperTriangular;
        }


};

#endif  // TO_QP_H
