/*
 * OptiNLC_LineSearch.h
 *
 * This file defines the LineSearch class, which implements various line search algorithms for optimization problems within the OptiNLC toolbox.
 *
 * Author: Reza Dariani
 * Email: reza.dariani@dlr.de
 */
#ifndef OPTINLC_LINESEARCH_ALGORITHMS_H
#define OPTINLC_LINESEARCH_ALGORITHMS_H

#include <iostream>
#include "OptiNLC_Solver.h"
#include "OptiNLC_Engine.h"


template <typename Scalar, int InputSize, int StateSize, int ConstraintSize, int NumberOfControlPoints>
class OptiNLC_LineSearch {
public:
using OptProblem = OptiNLC_Engine<Scalar, InputSize, StateSize, ConstraintSize,NumberOfControlPoints>;
using TimeVector  = VECTOR<Scalar, NumberOfControlPoints+1>;  
    OptiNLC_LineSearch(const OptProblem&  OP, double perturbation =1e-12) : OP_(OP){
        this->perturbation = perturbation;
        resetHessian = false;
    }

    // The maximum step size alpha such that x0 + alpha * d stays within the bounds
    double max(const VECTOR<Scalar, InputSize>& u, 
               const VECTOR<Scalar, InputSize>& direction, 
               const VECTOR<Scalar, InputSize>& lb, 
               const VECTOR<Scalar, InputSize>& ub)
    {
        auto step = std::numeric_limits<Scalar>::infinity();
        for (int i = 0; i < InputSize; i++)
        {
            if (direction[i] > 0.0)
            {
                step = std::min(step, (ub[i] - u[i]) / direction[i]);
            }
            else if (direction[i] < 0.0)
            {
                step = std::min(step, (lb[i] - u[i]) / direction[i]);
            }
        }

        return step;
    }
   
// Raydan line search with safeguards and nonmonotone strategy
    double raydanLineSearch(const VECTOR<Scalar, StateSize>& x,
                             const VECTOR<Scalar, InputSize>& u, 
                             const VECTOR<Scalar, InputSize>& direction,
                             double initialStepSize = 1.0,
                             double alpha = 0.5, 
                             double beta = 0.5,
                             int maxIterations = 50) {
        
        resetHessian = false;
        double stepSize = initialStepSize;
        OP_.evaluate(x,u,perturbation,2);
        double initialObjective = OP_.getObjectiveFunctionValue();
        VECTOR<Scalar,InputSize>  gradient = OP_.getGradient();
        //double constraintViolation = OP_.maxConstrainsViolation(x,u);
        //std::cout<<"\n"<<constraintViolation;


        double minStepSize = 1e-8;
        double maxStepSize = 1e8;
        double delta = 0.1; // Tolerance for nonmonotonicity
        double eta = 0.5;   // Scaling factor for step size adjustments  
        double rho = 0.1;             

        
        // Monotone search
        VECTOR<Scalar,InputSize> newU = u;
        for (int i = 1; i <= maxIterations; i++) {
            newU = u+ stepSize * direction;
            OP_.evaluate(x,newU,perturbation,0);
            double newObjective = OP_.getObjectiveFunctionValue();
            double expectedImprovement = alpha * stepSize * gradient.dotProduct(direction);
            bool condition = newObjective <= initialObjective + expectedImprovement;
           // double constraintViolation = OP_.maxConstrainsViolation(x,newU);         
            if (condition) {
                if (stepSize < minStepSize) {resetHessian = true;}
                return stepSize;
            }

            stepSize *= beta; // Reduce step size
            stepSize = std::min(stepSize, maxStepSize);
            // Adjust step size for nonmonotonicity
            if (newObjective > initialObjective + delta * expectedImprovement) {
                stepSize *= eta;
            }            
            // Check for early exit if step size is too small
            if (stepSize < minStepSize) {
                stepSize = minStepSize;
                resetHessian = true;
                return stepSize;
            }            
        }    

        // Safeguarded nonmonotone search didn't converge, return the smallest step size
        return stepSize;
    }



    double directionalDerivative(const VECTOR<Scalar, StateSize>& x,
                                 const VECTOR<Scalar, InputSize>& u, 
                                 const VECTOR<Scalar, InputSize>& direction,
                                const Eigen::MatrixXd& hessian, 
                                const VECTOR<Scalar,InputSize>&gradient,
                                const double initialObjective, 
                                const TimeVector& time,
                                int MAX_ITER=100,  
                                double rho = 0.5, 
                                double eta= 0.25, 
                                double tau = 0.5) {
        resetHessian = false;
        double minStepSize = 1e-3;
        double constraintViolation_L1 = OP_.L1ConstrainsViolation(x,u, time);  
        auto obj_grad = gradient.getDataAsEigen();
        auto p = direction.getDataAsEigen();
        double mu = (obj_grad.dot(p) + 0.5 * p.dot(hessian * p)) / ((1 - rho) * constraintViolation_L1);
        double directionalDerivative = obj_grad.dot(p) - mu*constraintViolation_L1;
        double merit = initialObjective + mu * constraintViolation_L1;
        // Termination criterion based on a tolerance
        double tolerance = 1e-6;        
        double alpha = 1.0;
        int i;
        double objValue_new, merit_new;
        for(i=1; i<MAX_ITER; i++)
        {

            auto u_new = u + alpha * direction;
            OP_.evaluate(x,u_new,time,perturbation,0);
            objValue_new = OP_.getObjectiveFunctionValue();
            merit_new = objValue_new + mu *  constraintViolation_L1; 
            if(merit_new <= merit + alpha*eta*directionalDerivative|| std::abs(alpha * directionalDerivative) < tolerance) {
                break;                
            } 
            else {
                alpha = tau * alpha;
            }

        }
        if (alpha < minStepSize) {
            resetHessian = true;
            //minStepSize = minStepSize;
            return alpha;
        } 
        return alpha;        
    }
    bool checkFullStep(const VECTOR<Scalar, StateSize>& x,
                        const VECTOR<Scalar, InputSize>& u, 
                        const VECTOR<Scalar, InputSize>& direction,
                        const VECTOR<Scalar, ConstraintSize>&lambda,
                        const TimeVector& time,
                        double cn, double tol){
        std::cout<<"\ncheck";
        VECTOR<Scalar,InputSize> newU;
        newU = u +  direction; //full step
        OP_.evaluate(x,newU,time, perturbation,3);
        auto constr = OP_.getConstraints();
        double cnNew = 0.0;
        cnNew = fmax(cnNew, (OP_.getL() - constr).maxCoeff());
        cnNew = fmax(cnNew, (constr - OP_.getU()).maxCoeff()); 
        VECTOR<Scalar,InputSize>  gradLagrange;
        auto gradObj = OP_.getGradient();
        auto jacobian = OP_.getJacobian();
        gradLagrange.set(gradObj);
        VECTOR<Scalar,ConstraintSize-InputSize> lambda_head;
        VECTOR<Scalar,InputSize> lambda_tail;
        MATRIX<ConstraintSize-InputSize, InputSize> jacobian_part;
        std::memcpy(&lambda_head[0], &lambda[0],sizeof(lambda_head) );    
        std::memcpy(&lambda_tail[0], &lambda[ConstraintSize-InputSize],sizeof(lambda_tail) );  

        for (int i = 0; i < ConstraintSize-InputSize; ++i) {
            for (int j = 0; j < InputSize; ++j) {
                jacobian_part[i][j] = jacobian[i][j];
            }
        }
        auto lambda_jac = (lambda_head * jacobian_part);
        gradLagrange = (gradLagrange - lambda_jac);
        gradLagrange.set(gradLagrange - lambda_tail);      
        double lgn = gradLagrange.norm_inf();
        double lambda_n = lambda.norm_inf();
        double tolNew = lgn / (1.0 + lambda_n);

        if(  cnNew + tolNew  <0.999999 * ( cn +tol ) )    {
            std::cout<<"\nAccept full step";
            //deactivateReset();
            return true;

        }
        return false;
            
        
    }  
    /*  
    double ExactLineSearch(const VECTOR<Scalar, StateSize>& x,
                           const VECTOR<Scalar, InputSize>& u, 
                           const VECTOR<Scalar, InputSize>& direction,
                           double initial_step_size=1.0, 
                           const double c1=1e-4, 
                           const double alpha=0.1, 
                           const double beta=0.5, 
                           const int max_iterations=100) {

        double step_size = initial_step_size;
        OP_.evaluate(x,u,perturbation,2);  
        double f_current = OP_.getObjectiveFunctionValue();
        VECTOR<Scalar,InputSize>  grad_current = OP_.getGradient(); 
        double rho = 0.5;
        double constraintViolation_L1 = OP_.L1ConstrainsViolation(x,u);  
        double mu = (grad_current.dotProduct(direction) + 0.5 * direction.dotProduct(direction)) / ((1 - rho) * constraintViolation_L1);        
        double merit = f_current + mu * constraintViolation_L1;
        for (int iter = 0; iter < max_iterations; ++iter) {
            OP_.evaluate(x,u+step_size * direction,perturbation,0); 
            double merit_new = OP_.getObjectiveFunctionValue() + mu *  OP_.L1ConstrainsViolation(x,u+step_size * direction);
            // Armijo-Goldstein condition
            if (merit_new <= merit) {
                return step_size; // Accept the step size
            } else {
                step_size *= beta; // Reduce the step size
            }
        }

        return step_size; // Return the last accepted step size
    }
    */
    bool reset(){
        return resetHessian;
    }
    void deactivateReset()
    {
        resetHessian = false;
    }
    private:
    
    const OptProblem& OP_;  // Reference to the OCP instance
    double perturbation;
    bool resetHessian;


};

#endif  // LINESEARCH_H
