# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/tmp/casadi/docs/examples/cplusplus/daebuilder.cpp" "/tmp/casadi/build/docs/examples/cplusplus/CMakeFiles/daebuilder.dir/daebuilder.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "CASADI_DEFAULT_COMPILER_PLUGIN=shell"
  "CASADI_IS_RELEASE=0"
  "CASADI_MAJOR_VERSION=3"
  "CASADI_MINOR_VERSION=6"
  "CASADI_PATCH_VERSION=7"
  "CASADI_SNPRINTF=snprintf"
  "CASADI_VERSION=31"
  "HAVE_MKSTEMPS"
  "USE_CXX11"
  "WITH_DEEPBIND"
  "WITH_DEPRECATED_FEATURES"
  "WITH_DL"
  "_SCL_SECURE_NO_WARNINGS"
  "_USE_MATH_DEFINES"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "../."
  "."
  "../docs/examples/cplusplus/../.."
  "casadi/core/runtime"
  "../casadi/core/../.."
  "casadi/core/../.."
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/tmp/casadi/build/casadi/core/CMakeFiles/casadi.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
